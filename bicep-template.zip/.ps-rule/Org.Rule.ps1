# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

# Note:
# This script demonstrates using PowerShell-based rules.
