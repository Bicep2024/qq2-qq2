# Security Policy

## Supported Versions

This is a learning and development project, as such there is no direct support given for external users.

## Reporting a Vulnerability

I encourage any and all security vulnerabilities to be reported to `security@mx-mail.io` or by opening an issue through GitHub.
