# CONTRIBUTING

This is a personal project which I use to learn and apply new tools, technologies, approaches and generally to learn through. As such I am not looking for any direct contributions however I am always open to constructive feedback, feature requests and issues being raised.
